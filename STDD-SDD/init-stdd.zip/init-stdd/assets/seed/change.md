# {{CHANGE_TITLE}}

- 变更 ID `{{CHANGE_ID}}`
- 状态 待评审
- 需求负责人 待定

## 目标

{{GOAL}}

## 范围与决策

<!-- 产品写清目标用户、成功结果、非目标和兼容要求。把假设、开放事项和决策人记在这里。 -->

## 角色交接

- 产品维护[需求与验收场景](spec.md)。
- 设计维护[体验设计](ux-design.md)，将关键状态关联到场景。
- 研发维护[实施方案与任务](tasks.md){{DESIGN_HANDOFF}}。
- 测试维护[验收计划](test-plan.md)和[实际验收记录](verification.md)。
