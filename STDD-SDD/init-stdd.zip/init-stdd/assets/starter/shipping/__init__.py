"""Shipping quote example."""
